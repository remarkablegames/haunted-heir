label day3_good_ending:

    play music [hide_and_seek1, hide_and_seek2, hide_and_seek3]

    scene bg interior entrance day with dissolve

    show lord smirk with dissolve

    lord "Good morning,{w=0.3} [player_name]."
    lord "How was your night?"

    player "It was nice, actually."
    player "I feel like the air suddenly became lighter."

    lord tsun "Wait...{w=1} did you?"

    player "Yes,{w=0.3} she’s finally at peace now."

    lord disgust "I never told you who she was...{w=1} did I?"

    player "No,{w=0.1} you didn’t.{w=0.3} Do you know her?"

    lord sigh "Yes...{w=1} she’s my daughter."
    lord sad "I...{w=0.6} couldn’t leave her...{w=0.9} not while she was still suffering..."

    player "I’m sorry to hear that."
    player "She’s in a better place now."

    lord blush "Indeed...{w=1} and thank you for that."
    lord "Also...{w=0.6} the papers have been finalized."

    lord smile "Congratulations...{w=0.3} on inheriting this mansion."

    lord happy "I’m off...{w=0.5} on my own journey now."
    lord "Take care..."

    hide lord with Dissolve(1)

    pause 0.5

    scene bg interior entrance evening with Dissolve(1)

    player "I guess I won’t be as rich as I imagined."
    player "But even though I’d given up the treasure,{w=0.2} I feel like my soul is at peace."

    jump end
