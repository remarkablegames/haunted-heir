label basement_room(with_dissolve=True):

    if visits_basement == 1:
        jump basement_room_first_visit

    if night:
        if with_dissolve:
            scene bg basement dark with dissolve

            if handed_treasure != "ghost":
                show ghost angry at center, opacity(0.5), idle
                with dissolve
        else:
            scene bg basement dark

            if handed_treasure != "ghost":
                show ghost angry at center, opacity(0.5), idle

    else:
        if with_dissolve:
            scene bg basement light with dissolve
        else:
            scene bg basement light

        if visits_basement > 1:
            show screen basement_book

    menu:
        "What do you want to do?"

        "Talk to the Ghost" if night and handed_treasure != "ghost":
            stop bleep
            jump basement_ghost

        "Look around":
            stop bleep
            call screen explore_basement_room

        "Go upstairs":
            stop bleep
            hide screen basement_book
            jump explore_inside_day

    return


screen explore_basement_room():
    use back("basement_room")


screen basement_book():
    imagebutton:
        xpos 980
        ypos 387
        idle "items/book.webp"
        action Jump("basement_book")
        at scale(0.13), tint("#666")


label basement_book:

    player "It’s the Lord’s book."

    menu:
        "Should I take a peek?"

        "Yes":
            stop bleep
            play sound paper

            player "The last entry is dated November 11th."

            "“I can’t wait to surprise my beloved on her birthday today.{w}\nI’ll treasure this day forever.”"

            player "I wonder what that means..."

        "No":
            stop bleep
            player "It’s best not to snoop through other people’s belongings."

    call screen explore_basement_room


label basement_ghost:
    show ghost angry talk at center, opacity(0.5), idle

    menu:
        ghost "{sc}What do you have for me?"

        "Hand the treasure over" if item.is_inventory("necklace"):
            play sound treasure

            $ item.use("necklace")
            $ handed_treasure = "ghost"

            player "Is this what you’re looking for?"

            ghost sad smile "{sc}Ah...{w=0.6} Yes...{w=0.9} This is my precious..."

            hide ghost with dissolve

            play sound ghost

            show miss at center, opacity(0.8), scale(1.2)
            with dissolve

            show miss neutral

            ghost "... my precious necklace."

            show miss happy

            ghost "I can finally rest in peace..."

            show miss sarcastic

            ghost "Thank you..."

            show miss smile

            ghost "Farewell, [player_name]."

            hide miss with Dissolve(1)

            call basement_room(with_dissolve=False)

        "Nevermind":
            call basement_room(with_dissolve=False)
